function Suspicion() {
    return <div>Suspicion</div>;
}

export default Suspicion;

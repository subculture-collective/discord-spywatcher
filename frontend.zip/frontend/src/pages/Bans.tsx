function Bans() {
    return <div>Bans</div>;
}

export default Bans;
